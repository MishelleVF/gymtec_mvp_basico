// src/app/recommendations/page.tsx
"use client";

import { useEffect, useState } from "react";
import MobileShell from "@/components/layout/MobileShell";
import RecommendationCard from "@/components/cards/RecommendationCard";
import InsightCard from "@/components/cards/InsightCard";
import LoadingState from "@/components/ui/LoadingState";
import ErrorState from "@/components/ui/ErrorState";
import DataSourceBanner from "@/components/ui/DataSourceBanner";
import {
  BusySlot,
  DataSource,
  TodayRecommendationResponse,
} from "@/types/gymtec";
import { STUDENT_ID, todayIso } from "@/lib/utils";
import { getTodayRecommendations } from "@/services/gymtecApi";
import Badge, { OccupancyBadge } from "@/components/ui/Badge";
import Card from "@/components/ui/Card";

export default function RecommendationsPage() {
  const [data, setData] = useState<TodayRecommendationResponse | null>(null);
  const [source, setSource] = useState<DataSource>("live");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const busy: BusySlot[] =
        typeof window !== "undefined"
          ? JSON.parse(window.localStorage.getItem("gymtec.busySlots") || "[]")
          : [];
      const res = await getTodayRecommendations({
        student_id: STUDENT_ID,
        date: todayIso(),
        busy_slots: busy,
      });
      setData(res.data);
      setSource(res.source);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  return (
    <MobileShell>
      <div className="text-[11px] font-medium text-neutral-700 mt-1">
        PARA TI · HOY
      </div>
      <h1 className="text-[20px] font-medium text-ink-900 leading-tight mt-0.5">
        Top 3 horarios para ti
      </h1>
      <p className="text-[13px] text-neutral-700 mt-1.5 leading-relaxed">
        Ordenados por compatibilidad con tu horario, aforo y carga académica.
      </p>

      <div className="mt-3">
        <DataSourceBanner source={source} />
      </div>

      {loading && <LoadingState />}
      {!loading && error && (
        <ErrorState message={error} onRetry={load} />
      )}

      {!loading && data && (
        <>
          <div className="flex flex-col gap-2.5 mt-3">
            {data.top_recommendations.map((rec, i) => (
              <RankedCard key={rec.start_time} rec={rec} index={i} />
            ))}
          </div>

          <div className="mt-4">
            <InsightCard text={data.insight} />
          </div>
        </>
      )}
    </MobileShell>
  );
}

function RankedCard({
  rec,
  index,
}: {
  rec: TodayRecommendationResponse["top_recommendations"][number];
  index: number;
}) {
  const confidencePct = Math.round(rec.confidence * 100);
  const isBest = index === 0;

  return (
    <Card accent={isBest ? "left" : "none"} className="p-3.5">
      <div className="flex items-start justify-between">
        <div>
          {isBest ? (
            <Badge tone="primary">{rec.label}</Badge>
          ) : (
            <Badge tone={index === 1 ? "info" : "neutral"}>{rec.label}</Badge>
          )}
          <div
            className={
              isBest
                ? "text-[22px] font-medium text-ink-900 tracking-tight mt-2"
                : "text-lg font-medium text-ink-900 mt-1.5"
            }
          >
            {rec.start_time} — {rec.end_time}
          </div>
        </div>
        <div className="text-right">
          <div
            className={
              isBest ? "text-lg font-medium text-ink-900" : "text-base font-medium text-ink-900"
            }
          >
            {confidencePct}%
          </div>
          <div className="text-[10px] text-neutral-500">confianza</div>
        </div>
      </div>
      <div className="flex items-center justify-between mt-2.5">
        <span className="text-[11px] text-neutral-700">Aforo</span>
        <OccupancyBadge level={rec.expected_occupancy} />
      </div>
      <p className="text-[11px] text-neutral-700 leading-relaxed mt-2">
        {rec.reason}
      </p>
    </Card>
  );
}
