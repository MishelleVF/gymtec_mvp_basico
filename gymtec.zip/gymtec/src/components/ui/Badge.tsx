// src/components/ui/Badge.tsx
import { ReactNode } from "react";
import { cn, occupancyStyle } from "@/lib/utils";
import { OccupancyLevel } from "@/types/gymtec";

interface BadgeProps {
  children: ReactNode;
  tone?: "neutral" | "info" | "primary" | "gold";
  className?: string;
}

export default function Badge({
  children,
  tone = "neutral",
  className,
}: BadgeProps) {
  const tones: Record<NonNullable<BadgeProps["tone"]>, string> = {
    neutral: "bg-neutral-100 text-neutral-700",
    info: "bg-[#E6F1FB] text-ink-700",
    primary: "bg-ink-500 text-white",
    gold: "bg-[#FAEEDA] text-gold-700",
  };

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 text-[11px] font-medium px-2.5 py-1 rounded-pill tracking-wide",
        tones[tone],
        className
      )}
    >
      {children}
    </span>
  );
}

interface OccupancyBadgeProps {
  level: OccupancyLevel;
  className?: string;
}

export function OccupancyBadge({ level, className }: OccupancyBadgeProps) {
  const s = occupancyStyle(level);
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 text-[11px] font-medium px-2.5 py-1 rounded-pill",
        s.bg,
        s.fg,
        className
      )}
    >
      <span
        aria-hidden
        className="w-2 h-2 rounded-sm"
        style={{ background: s.dot }}
      />
      {s.label}
    </span>
  );
}
