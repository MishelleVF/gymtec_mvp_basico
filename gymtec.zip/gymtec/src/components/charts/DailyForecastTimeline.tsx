// src/components/charts/DailyForecastTimeline.tsx
import { DailyForecastPoint, OccupancyLevel } from "@/types/gymtec";
import { occupancyStyle } from "@/lib/utils";

interface Props {
  points: DailyForecastPoint[];
  highlightTime?: string; // e.g. "15:00"
}

const HEIGHT_BY_LEVEL: Record<OccupancyLevel, number> = {
  Bajo: 18,
  Medio: 26,
  Alto: 32,
};

export default function DailyForecastTimeline({ points, highlightTime }: Props) {
  if (points.length === 0) return null;
  const cols = points.length;

  return (
    <div>
      <div
        className="grid gap-1 items-end"
        style={{ gridTemplateColumns: `repeat(${cols}, 1fr)` }}
      >
        {points.map((p) => {
          const s = occupancyStyle(p.expected_occupancy);
          const isNow = p.time === highlightTime;
          return (
            <div
              key={p.time}
              className="rounded-md relative"
              style={{
                background: s.solidBg,
                height: `${HEIGHT_BY_LEVEL[p.expected_occupancy]}px`,
                boxShadow: isNow ? "inset 0 0 0 2px #042C53" : undefined,
              }}
              aria-label={`${p.time} aforo ${p.expected_occupancy}`}
            />
          );
        })}
      </div>
      <div
        className="grid gap-1 mt-1"
        style={{ gridTemplateColumns: `repeat(${cols}, 1fr)` }}
      >
        {points.map((p) => (
          <div
            key={p.time}
            className={
              p.time === highlightTime
                ? "text-[9px] text-ink-900 font-medium text-center"
                : "text-[9px] text-neutral-500 text-center"
            }
          >
            {p.time.slice(0, 2)}
          </div>
        ))}
      </div>

      {/* Legend */}
      <div className="flex gap-3 mt-2.5 text-[10px] text-neutral-700">
        {(["Bajo", "Medio", "Alto"] as OccupancyLevel[]).map((lvl) => {
          const s = occupancyStyle(lvl);
          return (
            <span key={lvl} className="flex items-center gap-1.5">
              <span
                className="w-2.5 h-2.5 rounded-sm"
                style={{ background: s.solidBg }}
                aria-hidden
              />
              {s.label}
            </span>
          );
        })}
      </div>
    </div>
  );
}
